/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.16-MariaDB, for Linux (x86_64)
--
-- Host: db    Database: cyber_manager
-- ------------------------------------------------------
-- Server version	11.4.10-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts_user`
--

DROP TABLE IF EXISTS `accounts_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user`
--

LOCK TABLES `accounts_user` WRITE;
/*!40000 ALTER TABLE `accounts_user` DISABLE KEYS */;
INSERT INTO `accounts_user` VALUES
(1,'pbkdf2_sha256$600000$XmSa9v3gSRyyVY41kH8ZqL$B/IluI2+lrQyMjwulVeyUnDiCD8IRM3O/BiR+DvynaQ=',NULL,1,'adm','','','admin@gmail.com',1,1,'2026-05-11 11:58:08.951602','','admin'),
(2,'pbkdf2_sha256$600000$5QQs9B0xjh5jPV2h2tP8zR$amTBsrASO7n9eVUOOuj+1odU8sPxyHt4tbSd8786WtU=','2026-05-11 12:12:25.943557',1,'juri','','','juri@gmail.com',1,1,'2026-05-11 12:12:09.017072','','admin');
/*!40000 ALTER TABLE `accounts_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_user_groups`
--

DROP TABLE IF EXISTS `accounts_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_user_groups_user_id_group_id_59c0b32f_uniq` (`user_id`,`group_id`),
  KEY `accounts_user_groups_group_id_bd11a704_fk_auth_group_id` (`group_id`),
  CONSTRAINT `accounts_user_groups_group_id_bd11a704_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `accounts_user_groups_user_id_52b62117_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user_groups`
--

LOCK TABLES `accounts_user_groups` WRITE;
/*!40000 ALTER TABLE `accounts_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accounts_user_user_permissions`
--

DROP TABLE IF EXISTS `accounts_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_user_user_permi_user_id_permission_id_2ab516c2_uniq` (`user_id`,`permission_id`),
  KEY `accounts_user_user_p_permission_id_113bb443_fk_auth_perm` (`permission_id`),
  CONSTRAINT `accounts_user_user_p_permission_id_113bb443_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `accounts_user_user_p_user_id_e4f0a161_fk_accounts_` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts_user_user_permissions`
--

LOCK TABLES `accounts_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `accounts_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditlog_auditlog`
--

DROP TABLE IF EXISTS `auditlog_auditlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditlog_auditlog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(100) NOT NULL,
  `entity_id` varchar(100) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `created_at` datetime(6) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auditlog_auditlog_user_id_78033f61_fk_accounts_user_id` (`user_id`),
  CONSTRAINT `auditlog_auditlog_user_id_78033f61_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlog_auditlog`
--

LOCK TABLES `auditlog_auditlog` WRITE;
/*!40000 ALTER TABLE `auditlog_auditlog` DISABLE KEYS */;
INSERT INTO `auditlog_auditlog` VALUES
(1,'session_started','Session','1','{\"voucher_code\": \"746EE1\", \"service_type\": \"wifi\", \"session_mode\": \"countdown\", \"remaining_seconds\": 60, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:12:42.498302',2),
(2,'session_finished','Session','1','{\"final_price\": \"0.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 60, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:12:51.688901',2),
(3,'session_started','Session','2','{\"voucher_code\": \"F5CD7C\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:13:08.159658',2),
(4,'session_finished','Session','2','{\"final_price\": \"0.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:13:13.717178',2),
(5,'session_paid','Session','2','{\"session_id\": 2, \"service_type\": \"wifi\", \"final_price\": \"0.00\", \"paid_at\": \"2026-05-11T12:20:47.765218+00:00\"}','2026-05-11 12:20:47.835963',2),
(6,'session_paid','Session','1','{\"session_id\": 1, \"service_type\": \"wifi\", \"final_price\": \"0.00\", \"paid_at\": \"2026-05-11T12:20:49.286062+00:00\"}','2026-05-11 12:20:49.315738',2),
(7,'session_started','Session','3','{\"voucher_code\": \"380C0F\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:21:00.523101',2),
(8,'session_finished','Session','3','{\"final_price\": \"0.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:21:06.019929',2),
(9,'session_paid','Session','3','{\"session_id\": 3, \"service_type\": \"wifi\", \"final_price\": \"0.00\", \"paid_at\": \"2026-05-11T12:21:09.191760+00:00\"}','2026-05-11 12:21:09.198919',2),
(10,'session_started','Session','4','{\"voucher_code\": \"077573\", \"service_type\": \"wifi\", \"session_mode\": \"countdown\", \"remaining_seconds\": 60, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:21:17.399531',2),
(11,'session_finished','Session','4','{\"final_price\": \"0.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 60, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:21:28.646712',2),
(12,'session_paid','Session','4','{\"session_id\": 4, \"service_type\": \"wifi\", \"final_price\": \"0.00\", \"paid_at\": \"2026-05-11T12:21:44.389729+00:00\"}','2026-05-11 12:21:44.409144',2),
(13,'session_started','Session','5','{\"voucher_code\": \"42CE42\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:21:47.373334',2),
(14,'session_finished','Session','5','{\"final_price\": \"300.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:21:59.322207',2),
(15,'session_paid','Session','5','{\"session_id\": 5, \"service_type\": \"wifi\", \"final_price\": \"300.00\", \"paid_at\": \"2026-05-11T12:22:00.821750+00:00\"}','2026-05-11 12:22:00.849243',2),
(16,'session_started','Session','6','{\"voucher_code\": \"843223\", \"service_type\": \"wifi\", \"session_mode\": \"countdown\", \"remaining_seconds\": 180, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:22:06.763795',2),
(17,'session_finished','Session','6','{\"final_price\": \"300.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 180, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:22:10.614229',2),
(18,'session_paid','Session','6','{\"session_id\": 6, \"service_type\": \"wifi\", \"final_price\": \"300.00\", \"paid_at\": \"2026-05-11T12:22:24.661263+00:00\"}','2026-05-11 12:22:24.673324',2),
(19,'session_started','Session','7','{\"voucher_code\": \"D33C32\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:30:50.665921',2),
(20,'session_started','Session','8','{\"voucher_code\": null, \"service_type\": \"console\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": true}','2026-05-11 12:30:56.465858',2),
(21,'session_finished','Session','7','{\"final_price\": \"300.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:31:02.943591',2),
(22,'session_finished','Session','8','{\"final_price\": \"200.00\", \"consumed_seconds\": 9, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:31:05.969517',2),
(23,'session_paid','Session','8','{\"session_id\": 8, \"service_type\": \"console\", \"final_price\": \"200.00\", \"paid_at\": \"2026-05-11T12:31:16.433576+00:00\"}','2026-05-11 12:31:16.448008',2),
(24,'session_paid','Session','7','{\"session_id\": 7, \"service_type\": \"wifi\", \"final_price\": \"300.00\", \"paid_at\": \"2026-05-11T12:31:18.866500+00:00\"}','2026-05-11 12:31:18.875982',2),
(25,'session_started','Session','9','{\"voucher_code\": \"099C8E\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:31:48.999850',2),
(26,'session_finished','Session','9','{\"final_price\": \"300.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:31:54.987764',2),
(27,'session_paid','Session','9','{\"session_id\": 9, \"service_type\": \"wifi\", \"final_price\": \"300.00\", \"paid_at\": \"2026-05-11T12:31:59.381008+00:00\"}','2026-05-11 12:31:59.400202',2),
(28,'session_started','Session','10','{\"voucher_code\": \"A3E2C1\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:32:01.468285',2),
(29,'session_finished','Session','10','{\"final_price\": \"300.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:32:05.276564',2),
(30,'session_paid','Session','10','{\"session_id\": 10, \"service_type\": \"wifi\", \"final_price\": \"300.00\", \"paid_at\": \"2026-05-11T12:32:08.837258+00:00\"}','2026-05-11 12:32:08.886561',2),
(31,'film_sale_created','FilmSale','1','{}','2026-05-11 12:32:17.148615',2),
(32,'session_started','Session','11','{\"voucher_code\": \"7C0325\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:33:03.155583',2),
(33,'session_finished','Session','11','{\"final_price\": \"300.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:33:05.373466',2),
(34,'session_paid','Session','11','{\"session_id\": 11, \"service_type\": \"wifi\", \"final_price\": \"300.00\", \"paid_at\": \"2026-05-11T12:33:16.254950+00:00\"}','2026-05-11 12:33:16.291741',2),
(35,'session_started','Session','12','{\"voucher_code\": \"5284E8\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": true, \"timer_starts_now\": false}','2026-05-11 12:33:34.249639',2),
(36,'session_finished','Session','12','{\"final_price\": \"300.00\", \"consumed_seconds\": 0, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 12:33:36.639013',2),
(37,'session_paid','Session','12','{\"session_id\": 12, \"service_type\": \"wifi\", \"final_price\": \"300.00\", \"paid_at\": \"2026-05-11T12:33:42.874452+00:00\"}','2026-05-11 12:33:42.887582',2),
(38,'session_started','Session','13','{\"voucher_code\": \"WIFI-000013\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": false, \"timer_starts_now\": true}','2026-05-11 13:13:34.306374',2),
(39,'session_finished','Session','13','{\"final_price\": \"300.00\", \"consumed_seconds\": 13, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 13:13:47.838757',2),
(40,'session_started','Session','14','{\"voucher_code\": \"WIFI-000014\", \"service_type\": \"wifi\", \"session_mode\": \"countdown\", \"remaining_seconds\": 60, \"mikrotik_enabled\": false, \"timer_starts_now\": true}','2026-05-11 13:14:10.095833',2),
(41,'session_started','Session','15','{\"voucher_code\": \"WIFI-000015\", \"service_type\": \"wifi\", \"session_mode\": \"countdown\", \"remaining_seconds\": 3600, \"mikrotik_enabled\": false, \"timer_starts_now\": true}','2026-05-11 13:14:44.522466',2),
(42,'session_finished','Session','15','{\"final_price\": \"300.00\", \"consumed_seconds\": 11, \"remaining_seconds\": 3589, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 13:14:56.231414',2),
(43,'session_finished','Session','14','{\"final_price\": \"300.00\", \"consumed_seconds\": 48, \"remaining_seconds\": 12, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 13:14:58.527643',2),
(44,'session_started','Session','16','{\"voucher_code\": \"WIFI-000016\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": false, \"timer_starts_now\": true}','2026-05-11 13:15:10.234467',2),
(45,'session_finished','Session','16','{\"final_price\": \"300.00\", \"consumed_seconds\": 2, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 13:15:12.408464',2),
(46,'session_started','Session','17','{\"voucher_code\": \"WIFI-000017\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": false, \"timer_starts_now\": true}','2026-05-11 13:29:02.108696',2),
(47,'session_finished','Session','17','{\"final_price\": \"300.00\", \"consumed_seconds\": 11, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 13:29:13.704233',2),
(48,'session_started','Session','18','{\"voucher_code\": \"WIFI-000018\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": false, \"timer_starts_now\": true}','2026-05-11 14:23:43.123881',2),
(49,'session_finished','Session','18','{\"final_price\": \"300.00\", \"consumed_seconds\": 4, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-11 14:23:47.431346',2),
(50,'session_started','Session','19','{\"voucher_code\": \"WIFI-000019\", \"service_type\": \"wifi\", \"session_mode\": \"open\", \"remaining_seconds\": 0, \"mikrotik_enabled\": false, \"timer_starts_now\": true}','2026-05-12 07:41:40.646631',2),
(51,'session_finished','Session','19','{\"final_price\": \"999.44\", \"consumed_seconds\": 3598, \"remaining_seconds\": 0, \"paused_duration_seconds\": 0, \"payment_status\": \"pending\"}','2026-05-12 08:41:38.991129',2);
/*!40000 ALTER TABLE `auditlog_auditlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can view log entry',1,'view_logentry'),
(5,'Can add permission',2,'add_permission'),
(6,'Can change permission',2,'change_permission'),
(7,'Can delete permission',2,'delete_permission'),
(8,'Can view permission',2,'view_permission'),
(9,'Can add group',3,'add_group'),
(10,'Can change group',3,'change_group'),
(11,'Can delete group',3,'delete_group'),
(12,'Can view group',3,'view_group'),
(13,'Can add content type',4,'add_contenttype'),
(14,'Can change content type',4,'change_contenttype'),
(15,'Can delete content type',4,'delete_contenttype'),
(16,'Can view content type',4,'view_contenttype'),
(17,'Can add session',5,'add_session'),
(18,'Can change session',5,'change_session'),
(19,'Can delete session',5,'delete_session'),
(20,'Can view session',5,'view_session'),
(21,'Can add user',6,'add_user'),
(22,'Can change user',6,'change_user'),
(23,'Can delete user',6,'delete_user'),
(24,'Can view user',6,'view_user'),
(25,'Can add station',7,'add_station'),
(26,'Can change station',7,'change_station'),
(27,'Can delete station',7,'delete_station'),
(28,'Can view station',7,'view_station'),
(29,'Can add tariff',8,'add_tariff'),
(30,'Can change tariff',8,'change_tariff'),
(31,'Can delete tariff',8,'delete_tariff'),
(32,'Can view tariff',8,'view_tariff'),
(33,'Can add session',9,'add_session'),
(34,'Can change session',9,'change_session'),
(35,'Can delete session',9,'delete_session'),
(36,'Can view session',9,'view_session'),
(37,'Can add session event',10,'add_sessionevent'),
(38,'Can change session event',10,'change_sessionevent'),
(39,'Can delete session event',10,'delete_sessionevent'),
(40,'Can view session event',10,'view_sessionevent'),
(41,'Can add film sale',11,'add_filmsale'),
(42,'Can change film sale',11,'change_filmsale'),
(43,'Can delete film sale',11,'delete_filmsale'),
(44,'Can view film sale',11,'view_filmsale'),
(45,'Can add audit log',12,'add_auditlog'),
(46,'Can change audit log',12,'change_auditlog'),
(47,'Can delete audit log',12,'delete_auditlog'),
(48,'Can view audit log',12,'view_auditlog');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_accounts_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES
(6,'accounts','user'),
(1,'admin','logentry'),
(12,'auditlog','auditlog'),
(3,'auth','group'),
(2,'auth','permission'),
(4,'contenttypes','contenttype'),
(8,'pricing','tariff'),
(11,'sales','filmsale'),
(5,'sessions','session'),
(9,'sessions_app','session'),
(10,'sessions_app','sessionevent'),
(7,'stations','station');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES
(1,'contenttypes','0001_initial','2026-05-11 11:56:02.601348'),
(2,'contenttypes','0002_remove_content_type_name','2026-05-11 11:56:02.876111'),
(3,'auth','0001_initial','2026-05-11 11:56:03.609076'),
(4,'auth','0002_alter_permission_name_max_length','2026-05-11 11:56:03.744875'),
(5,'auth','0003_alter_user_email_max_length','2026-05-11 11:56:03.768231'),
(6,'auth','0004_alter_user_username_opts','2026-05-11 11:56:03.787263'),
(7,'auth','0005_alter_user_last_login_null','2026-05-11 11:56:03.809807'),
(8,'auth','0006_require_contenttypes_0002','2026-05-11 11:56:03.815773'),
(9,'auth','0007_alter_validators_add_error_messages','2026-05-11 11:56:03.835610'),
(10,'auth','0008_alter_user_username_max_length','2026-05-11 11:56:03.855536'),
(11,'auth','0009_alter_user_last_name_max_length','2026-05-11 11:56:03.878049'),
(12,'auth','0010_alter_group_name_max_length','2026-05-11 11:56:03.947150'),
(13,'auth','0011_update_proxy_permissions','2026-05-11 11:56:03.963321'),
(14,'auth','0012_alter_user_first_name_max_length','2026-05-11 11:56:03.977764'),
(15,'accounts','0001_initial','2026-05-11 11:56:05.222430'),
(16,'admin','0001_initial','2026-05-11 11:56:05.666996'),
(17,'admin','0002_logentry_remove_auto_add','2026-05-11 11:56:05.690290'),
(18,'admin','0003_logentry_add_action_flag_choices','2026-05-11 11:56:05.710057'),
(19,'auditlog','0001_initial','2026-05-11 11:56:05.918224'),
(20,'pricing','0001_initial','2026-05-11 11:56:06.102271'),
(21,'pricing','0002_alter_tariff_hourly_rate_alter_tariff_minimum_price_and_more','2026-05-11 11:56:06.312869'),
(22,'sales','0001_initial','2026-05-11 11:56:06.514102'),
(23,'sessions','0001_initial','2026-05-11 11:56:06.639002'),
(24,'stations','0001_initial','2026-05-11 11:56:06.710705'),
(25,'sessions_app','0001_initial','2026-05-11 11:56:07.561644'),
(26,'sessions_app','0002_session_payment_fields','2026-05-11 11:56:07.954249'),
(27,'stations','0002_seed_wifi_console_stations','2026-05-11 11:56:08.003143');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES
('l53mf3kgaf9p7nyfmf4rujj92lfi7l3f','.eJxVjMsOwiAQRf-FtSEMdKC4dO83kIGZStXQpI-V8d-1SRe6veec-1KJtrWmbZE5jazOyqrT75apPKTtgO_UbpMuU1vnMetd0Qdd9HVieV4O9--g0lK_NYBh9EP2LopkpALFgwmdAYIY0GIQZGOtHZAh-B5s5M65ngK4PqCo9wfBKzZ6:1wMPUp:bKpbJuZoxYGm1ioGb2kA0lqBFwwvVX_VH0y7Hb_d8CQ','2026-05-25 12:12:27.640841');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pricing_tariff`
--

DROP TABLE IF EXISTS `pricing_tariff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pricing_tariff` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `service_type` varchar(100) NOT NULL,
  `hourly_rate` decimal(10,2) NOT NULL,
  `minimum_price` decimal(10,2) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `updated_by_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pricing_tariff_updated_by_id_e2a46e2d_fk_accounts_user_id` (`updated_by_id`),
  KEY `pricing_tariff_service_type_d3abdbdd` (`service_type`),
  CONSTRAINT `pricing_tariff_updated_by_id_e2a46e2d_fk_accounts_user_id` FOREIGN KEY (`updated_by_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pricing_tariff`
--

LOCK TABLES `pricing_tariff` WRITE;
/*!40000 ALTER TABLE `pricing_tariff` DISABLE KEYS */;
INSERT INTO `pricing_tariff` VALUES
(1,'wifi',1000.00,300.00,1,'2026-05-11 12:21:55.866023',2),
(2,'console',1000.00,200.00,1,'2026-05-11 12:21:55.915882',2),
(3,'product:Film',1.00,1000.00,1,'2026-05-11 12:21:56.134614',2),
(4,'product:Série',1.00,500.00,1,'2026-05-11 12:21:56.247165',2),
(5,'product:Gasy',1.00,800.00,1,'2026-05-11 12:21:56.186188',2),
(6,'product:Animé',1.00,600.00,1,'2026-05-11 12:21:55.963466',2),
(7,'product:Cache écran',1.00,2000.00,1,'2026-05-11 12:21:56.024269',2),
(8,'product:Dos',1.00,1500.00,1,'2026-05-11 12:21:56.078832',2);
/*!40000 ALTER TABLE `pricing_tariff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_filmsale`
--

DROP TABLE IF EXISTS `sales_filmsale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_filmsale` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `quantity` int(10) unsigned NOT NULL CHECK (`quantity` >= 0),
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `sold_at` datetime(6) NOT NULL,
  `sold_by_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_filmsale_sold_by_id_4f73f795_fk_accounts_user_id` (`sold_by_id`),
  CONSTRAINT `sales_filmsale_sold_by_id_4f73f795_fk_accounts_user_id` FOREIGN KEY (`sold_by_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_filmsale`
--

LOCK TABLES `sales_filmsale` WRITE;
/*!40000 ALTER TABLE `sales_filmsale` DISABLE KEYS */;
INSERT INTO `sales_filmsale` VALUES
(1,'Dos',1,1500.00,1500.00,'2026-05-11 12:32:17.136986',2);
/*!40000 ALTER TABLE `sales_filmsale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions_app_session`
--

DROP TABLE IF EXISTS `sessions_app_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions_app_session` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(255) NOT NULL,
  `voucher_code` varchar(30) DEFAULT NULL,
  `mikrotik_username` varchar(64) NOT NULL,
  `mikrotik_user_id` varchar(128) NOT NULL,
  `service_type` varchar(20) NOT NULL,
  `session_mode` varchar(20) NOT NULL,
  `countdown_seconds` int(10) unsigned NOT NULL CHECK (`countdown_seconds` >= 0),
  `remaining_seconds` int(10) unsigned NOT NULL CHECK (`remaining_seconds` >= 0),
  `started_at` datetime(6) NOT NULL,
  `expected_end_at` datetime(6) DEFAULT NULL,
  `ended_at` datetime(6) DEFAULT NULL,
  `last_resumed_at` datetime(6) DEFAULT NULL,
  `consumed_seconds` int(10) unsigned NOT NULL CHECK (`consumed_seconds` >= 0),
  `paused_duration_seconds` int(10) unsigned NOT NULL CHECK (`paused_duration_seconds` >= 0),
  `status` varchar(20) NOT NULL,
  `hourly_rate_snapshot` decimal(10,2) NOT NULL,
  `minimum_price_snapshot` decimal(10,2) NOT NULL,
  `final_price` decimal(10,2) DEFAULT NULL,
  `closed_by_id` bigint(20) DEFAULT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `station_id` bigint(20) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `paid_at` datetime(6) DEFAULT NULL,
  `paid_by_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `voucher_code` (`voucher_code`),
  KEY `sessions_app_session_closed_by_id_d0dcc97a_fk_accounts_user_id` (`closed_by_id`),
  KEY `sessions_app_session_created_by_id_28f4ccd6_fk_accounts_user_id` (`created_by_id`),
  KEY `sessions_app_session_station_id_f70c95d4_fk_stations_station_id` (`station_id`),
  KEY `sessions_app_session_paid_by_id_d1ff4ba1_fk_accounts_user_id` (`paid_by_id`),
  CONSTRAINT `sessions_app_session_closed_by_id_d0dcc97a_fk_accounts_user_id` FOREIGN KEY (`closed_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `sessions_app_session_created_by_id_28f4ccd6_fk_accounts_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `sessions_app_session_paid_by_id_d1ff4ba1_fk_accounts_user_id` FOREIGN KEY (`paid_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `sessions_app_session_station_id_f70c95d4_fk_stations_station_id` FOREIGN KEY (`station_id`) REFERENCES `stations_station` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions_app_session`
--

LOCK TABLES `sessions_app_session` WRITE;
/*!40000 ALTER TABLE `sessions_app_session` DISABLE KEYS */;
INSERT INTO `sessions_app_session` VALUES
(1,'ticket-6206','746EE1','746EE1','','wifi','countdown',60,60,'2026-05-11 12:12:41.772713',NULL,'2026-05-11 12:12:51.610243',NULL,0,0,'archived',0.00,0.00,0.00,2,2,1,'2026-05-11 12:12:41.953644','2026-05-11 12:20:49.286404','paid','2026-05-11 12:20:49.286062',2),
(2,'ticket-3406','F5CD7C','F5CD7C','','wifi','open',0,0,'2026-05-11 12:13:07.919240',NULL,'2026-05-11 12:13:13.609488',NULL,0,0,'archived',0.00,0.00,0.00,2,2,1,'2026-05-11 12:13:07.930335','2026-05-11 12:20:47.765703','paid','2026-05-11 12:20:47.765218',2),
(3,'ticket-8508','380C0F','380C0F','','wifi','open',0,0,'2026-05-11 12:21:00.485973',NULL,'2026-05-11 12:21:06.009013',NULL,0,0,'archived',0.00,0.00,0.00,2,2,1,'2026-05-11 12:21:00.494545','2026-05-11 12:21:09.191911','paid','2026-05-11 12:21:09.191760',2),
(4,'ticket-5052','077573','077573','','wifi','countdown',60,60,'2026-05-11 12:21:17.389233',NULL,'2026-05-11 12:21:28.633818',NULL,0,0,'archived',0.00,0.00,0.00,2,2,1,'2026-05-11 12:21:17.390320','2026-05-11 12:21:44.389879','paid','2026-05-11 12:21:44.389729',2),
(5,'ticket-3043','42CE42','42CE42','','wifi','open',0,0,'2026-05-11 12:21:47.364469',NULL,'2026-05-11 12:21:59.273656',NULL,0,0,'archived',500.00,300.00,300.00,2,2,1,'2026-05-11 12:21:47.366652','2026-05-11 12:22:00.821918','paid','2026-05-11 12:22:00.821750',2),
(6,'ticket-3575','843223','843223','','wifi','countdown',180,180,'2026-05-11 12:22:06.753838',NULL,'2026-05-11 12:22:10.591456',NULL,0,0,'archived',1000.00,300.00,300.00,2,2,1,'2026-05-11 12:22:06.755093','2026-05-11 12:22:24.661719','paid','2026-05-11 12:22:24.661263',2),
(7,'ticket-8213','D33C32','D33C32','','wifi','open',0,0,'2026-05-11 12:30:50.657943',NULL,'2026-05-11 12:31:02.928470',NULL,0,0,'archived',1000.00,300.00,300.00,2,2,1,'2026-05-11 12:30:50.658928','2026-05-11 12:31:18.866817','paid','2026-05-11 12:31:18.866500',2),
(8,'ticket-3003',NULL,'','','console','open',0,0,'2026-05-11 12:30:56.459815',NULL,'2026-05-11 12:31:05.942204',NULL,9,0,'archived',1000.00,200.00,200.00,2,2,51,'2026-05-11 12:30:56.461044','2026-05-11 12:31:16.433861','paid','2026-05-11 12:31:16.433576',2),
(11,'ticket-8854','7C0325','7C0325','','wifi','open',0,0,'2026-05-11 12:33:03.144149',NULL,'2026-05-11 12:33:05.360598',NULL,0,0,'archived',1000.00,300.00,300.00,2,2,1,'2026-05-11 12:33:03.146090','2026-05-11 12:33:16.255136','paid','2026-05-11 12:33:16.254950',2),
(12,'ticket-8657','5284E8','5284E8','','wifi','open',0,0,'2026-05-11 12:33:34.241557',NULL,'2026-05-11 12:33:36.594409',NULL,0,0,'archived',1000.00,300.00,300.00,2,2,1,'2026-05-11 12:33:34.242861','2026-05-11 12:33:42.874768','paid','2026-05-11 12:33:42.874452',2),
(13,'TEST CPMLET','WIFI-000013','WIFI-000013','','wifi','open',0,0,'2026-05-11 13:13:34.169230',NULL,'2026-05-11 13:13:47.821058',NULL,13,0,'completed',1000.00,300.00,300.00,2,2,1,'2026-05-11 13:13:34.185770','2026-05-11 13:13:54.116824','paid','2026-05-11 13:13:54.116557',2),
(14,'ticket-7405','WIFI-000014','WIFI-000014','','wifi','countdown',60,12,'2026-05-11 13:14:10.069567','2026-05-11 13:15:10.069567','2026-05-11 13:14:58.483542',NULL,48,0,'completed',1000.00,300.00,300.00,2,2,1,'2026-05-11 13:14:10.071166','2026-05-11 13:15:01.521379','paid','2026-05-11 13:15:01.521215',2),
(15,'ticket-7840','WIFI-000015','WIFI-000015','','wifi','countdown',3600,3589,'2026-05-11 13:14:44.517413','2026-05-11 14:14:44.517413','2026-05-11 13:14:56.168835',NULL,11,0,'completed',1000.00,300.00,300.00,2,2,10,'2026-05-11 13:14:44.518401','2026-05-11 13:15:02.792570','paid','2026-05-11 13:15:02.792196',2),
(16,'ticket-9743','WIFI-000016','WIFI-000016','','wifi','open',0,0,'2026-05-11 13:15:10.223898',NULL,'2026-05-11 13:15:12.395658',NULL,2,0,'completed',1000.00,300.00,300.00,2,2,1,'2026-05-11 13:15:10.225202','2026-05-11 13:15:34.129545','paid','2026-05-11 13:15:34.129152',2),
(17,'ticket-9048','WIFI-000017','WIFI-000017','','wifi','open',0,0,'2026-05-11 13:29:01.895073',NULL,'2026-05-11 13:29:13.670913',NULL,11,0,'completed',1000.00,300.00,300.00,2,2,1,'2026-05-11 13:29:01.940089','2026-05-11 13:29:13.673624','pending',NULL,NULL),
(18,'ticket-5522','WIFI-000018','WIFI-000018','','wifi','open',0,0,'2026-05-11 14:23:43.004030',NULL,'2026-05-11 14:23:47.419045',NULL,4,0,'completed',1000.00,300.00,300.00,2,2,1,'2026-05-11 14:23:43.012024','2026-05-11 14:23:47.420600','pending',NULL,NULL),
(19,'ticket-6021','WIFI-000019','WIFI-000019','','wifi','open',0,0,'2026-05-12 07:41:40.563092',NULL,'2026-05-12 08:41:38.873842',NULL,3598,0,'completed',1000.00,300.00,999.44,2,2,1,'2026-05-12 07:41:40.565216','2026-05-12 08:41:38.889037','pending',NULL,NULL);
/*!40000 ALTER TABLE `sessions_app_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions_app_sessionevent`
--

DROP TABLE IF EXISTS `sessions_app_sessionevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions_app_sessionevent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(20) NOT NULL,
  `timestamp` datetime(6) NOT NULL,
  `note` longtext NOT NULL,
  `session_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_app_session_session_id_19649f05_fk_sessions_` (`session_id`),
  KEY `sessions_app_sessionevent_user_id_f3f359bc_fk_accounts_user_id` (`user_id`),
  CONSTRAINT `sessions_app_session_session_id_19649f05_fk_sessions_` FOREIGN KEY (`session_id`) REFERENCES `sessions_app_session` (`id`),
  CONSTRAINT `sessions_app_sessionevent_user_id_f3f359bc_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions_app_sessionevent`
--

LOCK TABLES `sessions_app_sessionevent` WRITE;
/*!40000 ALTER TABLE `sessions_app_sessionevent` DISABLE KEYS */;
INSERT INTO `sessions_app_sessionevent` VALUES
(1,'start','2026-05-11 12:12:42.334234','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',1,2),
(2,'finish','2026-05-11 12:12:51.684764','Session terminée. Paiement en attente.',1,2),
(3,'start','2026-05-11 12:13:08.158026','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',2,2),
(4,'finish','2026-05-11 12:13:13.689743','Session terminée. Paiement en attente.',2,2),
(5,'archive','2026-05-11 12:20:47.829487','Paiement confirmé. Session archivée.',2,2),
(6,'archive','2026-05-11 12:20:49.301712','Paiement confirmé. Session archivée.',1,2),
(7,'start','2026-05-11 12:21:00.506746','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',3,2),
(8,'finish','2026-05-11 12:21:06.017522','Session terminée. Paiement en attente.',3,2),
(9,'archive','2026-05-11 12:21:09.195627','Paiement confirmé. Session archivée.',3,2),
(10,'start','2026-05-11 12:21:17.397514','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',4,2),
(11,'finish','2026-05-11 12:21:28.641885','Session terminée. Paiement en attente.',4,2),
(12,'archive','2026-05-11 12:21:44.396947','Paiement confirmé. Session archivée.',4,2),
(13,'start','2026-05-11 12:21:47.372317','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',5,2),
(14,'finish','2026-05-11 12:21:59.311211','Session terminée. Paiement en attente.',5,2),
(15,'archive','2026-05-11 12:22:00.834616','Paiement confirmé. Session archivée.',5,2),
(16,'start','2026-05-11 12:22:06.762123','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',6,2),
(17,'finish','2026-05-11 12:22:10.600615','Session terminée. Paiement en attente.',6,2),
(18,'archive','2026-05-11 12:22:24.665390','Paiement confirmé. Session archivée.',6,2),
(19,'start','2026-05-11 12:30:50.665116','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',7,2),
(20,'start','2026-05-11 12:30:56.464485','Session console démarrée immédiatement.',8,2),
(21,'finish','2026-05-11 12:31:02.939633','Session terminée. Paiement en attente.',7,2),
(22,'finish','2026-05-11 12:31:05.958849','Session terminée. Paiement en attente.',8,2),
(23,'archive','2026-05-11 12:31:16.438472','Paiement confirmé. Session archivée.',8,2),
(24,'archive','2026-05-11 12:31:18.872142','Paiement confirmé. Session archivée.',7,2),
(31,'start','2026-05-11 12:33:03.154721','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',11,2),
(32,'finish','2026-05-11 12:33:05.370161','Session terminée. Paiement en attente.',11,2),
(33,'archive','2026-05-11 12:33:16.284836','Paiement confirmé. Session archivée.',11,2),
(34,'start','2026-05-11 12:33:34.247688','Voucher créé. Le chrono démarre quand le client utilise le code sur le portail Hotspot.',12,2),
(35,'finish','2026-05-11 12:33:36.624844','Session terminée. Paiement en attente.',12,2),
(36,'archive','2026-05-11 12:33:42.881760','Paiement confirmé. Session archivée.',12,2),
(37,'start','2026-05-11 13:13:34.299072','Mode test sans MikroTik. Session WiFi démarrée immédiatement.',13,2),
(38,'finish','2026-05-11 13:13:47.834546','Session terminée. Paiement en attente.',13,2),
(39,'start','2026-05-11 13:14:10.094823','Mode test sans MikroTik. Session WiFi démarrée immédiatement.',14,2),
(40,'start','2026-05-11 13:14:44.521638','Mode test sans MikroTik. Session WiFi démarrée immédiatement.',15,2),
(41,'finish','2026-05-11 13:14:56.217187','Session terminée. Paiement en attente.',15,2),
(42,'finish','2026-05-11 13:14:58.517540','Session terminée. Paiement en attente.',14,2),
(43,'start','2026-05-11 13:15:10.231786','Mode test sans MikroTik. Session WiFi démarrée immédiatement.',16,2),
(44,'finish','2026-05-11 13:15:12.405239','Session terminée. Paiement en attente.',16,2),
(45,'start','2026-05-11 13:29:02.042238','Mode test sans MikroTik. Session WiFi démarrée immédiatement.',17,2),
(46,'finish','2026-05-11 13:29:13.696174','Session terminée. Paiement en attente.',17,2),
(47,'start','2026-05-11 14:23:43.082856','Mode test sans MikroTik. Session WiFi démarrée immédiatement.',18,2),
(48,'finish','2026-05-11 14:23:47.428754','Session terminée. Paiement en attente.',18,2),
(49,'start','2026-05-12 07:41:40.644640','Mode test sans MikroTik. Session WiFi démarrée immédiatement.',19,2),
(50,'finish','2026-05-12 08:41:38.969564','Session terminée. Paiement en attente.',19,2);
/*!40000 ALTER TABLE `sessions_app_sessionevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stations_station`
--

DROP TABLE IF EXISTS `stations_station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stations_station` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `station_type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stations_station`
--

LOCK TABLES `stations_station` WRITE;
/*!40000 ALTER TABLE `stations_station` DISABLE KEYS */;
INSERT INTO `stations_station` VALUES
(1,'Wifi 1','wifi','available',1),
(2,'Wifi 2','wifi','available',1),
(3,'Wifi 3','wifi','available',1),
(4,'Wifi 4','wifi','available',1),
(5,'Wifi 5','wifi','available',1),
(6,'Wifi 6','wifi','available',1),
(7,'Wifi 7','wifi','available',1),
(8,'Wifi 8','wifi','available',1),
(9,'Wifi 9','wifi','available',1),
(10,'Wifi 10','wifi','available',1),
(11,'Wifi 11','wifi','available',1),
(12,'Wifi 12','wifi','available',1),
(13,'Wifi 13','wifi','available',1),
(14,'Wifi 14','wifi','available',1),
(15,'Wifi 15','wifi','available',1),
(16,'Wifi 16','wifi','available',1),
(17,'Wifi 17','wifi','available',1),
(18,'Wifi 18','wifi','available',1),
(19,'Wifi 19','wifi','available',1),
(20,'Wifi 20','wifi','available',1),
(21,'Wifi 21','wifi','available',1),
(22,'Wifi 22','wifi','available',1),
(23,'Wifi 23','wifi','available',1),
(24,'Wifi 24','wifi','available',1),
(25,'Wifi 25','wifi','available',1),
(26,'Wifi 26','wifi','available',1),
(27,'Wifi 27','wifi','available',1),
(28,'Wifi 28','wifi','available',1),
(29,'Wifi 29','wifi','available',1),
(30,'Wifi 30','wifi','available',1),
(31,'Wifi 31','wifi','available',1),
(32,'Wifi 32','wifi','available',1),
(33,'Wifi 33','wifi','available',1),
(34,'Wifi 34','wifi','available',1),
(35,'Wifi 35','wifi','available',1),
(36,'Wifi 36','wifi','available',1),
(37,'Wifi 37','wifi','available',1),
(38,'Wifi 38','wifi','available',1),
(39,'Wifi 39','wifi','available',1),
(40,'Wifi 40','wifi','available',1),
(41,'Wifi 41','wifi','available',1),
(42,'Wifi 42','wifi','available',1),
(43,'Wifi 43','wifi','available',1),
(44,'Wifi 44','wifi','available',1),
(45,'Wifi 45','wifi','available',1),
(46,'Wifi 46','wifi','available',1),
(47,'Wifi 47','wifi','available',1),
(48,'Wifi 48','wifi','available',1),
(49,'Wifi 49','wifi','available',1),
(50,'Wifi 50','wifi','available',1),
(51,'Console 1','console','available',1),
(52,'Console 2','console','available',1),
(53,'Console 3','console','available',1),
(54,'Console 4','console','available',1),
(55,'Console 5','console','available',1),
(56,'Console 6','console','available',1),
(57,'Console 7','console','available',1),
(58,'Console 8','console','available',1),
(59,'Console 9','console','available',1),
(60,'Console 10','console','available',1),
(61,'Console 11','console','available',1),
(62,'Console 12','console','available',1),
(63,'Console 13','console','available',1),
(64,'Console 14','console','available',1),
(65,'Console 15','console','available',1),
(66,'Console 16','console','available',1),
(67,'Console 17','console','available',1),
(68,'Console 18','console','available',1),
(69,'Console 19','console','available',1),
(70,'Console 20','console','available',1),
(71,'Console 21','console','available',1),
(72,'Console 22','console','available',1),
(73,'Console 23','console','available',1),
(74,'Console 24','console','available',1),
(75,'Console 25','console','available',1),
(76,'Console 26','console','available',1),
(77,'Console 27','console','available',1),
(78,'Console 28','console','available',1),
(79,'Console 29','console','available',1),
(80,'Console 30','console','available',1),
(81,'Console 31','console','available',1),
(82,'Console 32','console','available',1),
(83,'Console 33','console','available',1),
(84,'Console 34','console','available',1),
(85,'Console 35','console','available',1),
(86,'Console 36','console','available',1),
(87,'Console 37','console','available',1),
(88,'Console 38','console','available',1),
(89,'Console 39','console','available',1),
(90,'Console 40','console','available',1),
(91,'Console 41','console','available',1),
(92,'Console 42','console','available',1),
(93,'Console 43','console','available',1),
(94,'Console 44','console','available',1),
(95,'Console 45','console','available',1),
(96,'Console 46','console','available',1),
(97,'Console 47','console','available',1),
(98,'Console 48','console','available',1),
(99,'Console 49','console','available',1),
(100,'Console 50','console','available',1);
/*!40000 ALTER TABLE `stations_station` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-06 12:19:39
